package org.example;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.util.List;
import java.util.concurrent.TimeUnit;

public class LoginPage {

    WebDriver webDriver;
    WebDriverWait webDriverWait;

    public LoginPage(WebDriver webDriver){
        this.webDriver=webDriver;
                this.webDriverWait=new WebDriverWait(webDriver,30,150);
    }
    public void login(String username,String password){
        webDriver.get("https://www.gittigidiyor.com/");
        Assert.assertEquals("GittiGidiyor",webDriver.getTitle());
        webDriverWait.until(ExpectedConditions.elementToBeClickable(By.className("Giriş Yap"))).click();
        Assert.assertArrayEquals("Üye Girişi-https://www.gittigidiyor.com/ ",webDriver.getTitle());
        webDriver.findElement(By.id("L-UserNameField")).clear();
        webDriver.findElement(By.id("L-UserNameField")).sendKeys((username));
        webDriver.findElement(By.id("L-PasswordField")).clear();
        webDriver.findElement(By.id("L-PasswordField")).sendKeys((password));
        webDriverWait.until(ExpectedConditions.elementToBeClickable(By.id("gg-login-enter"))).click();
        Assert.assertArrayEquals("GittiGidiyor",webDriver.getTitle());

    }

    }

